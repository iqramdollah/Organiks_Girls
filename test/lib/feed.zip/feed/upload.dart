import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:image_cropper/image_cropper.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

Future<void> showUploadDialog(
  BuildContext context,
  Function(bool) setUploading,
) async {
  final ImagePicker _picker = ImagePicker();
  File? _selectedMedia;
  String _caption = '';

  final picked = await _picker.pickImage(source: ImageSource.gallery);
  if (picked == null) return;

  final cropped = await ImageCropper().cropImage(sourcePath: picked.path);
  if (cropped == null) return;

  _selectedMedia = File(cropped.path);

  showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    shape: RoundedRectangleBorder(
      borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
    ),
    builder: (context) {
      return Padding(
        padding: EdgeInsets.only(
          top: 16,
          left: 16,
          right: 16,
          bottom: MediaQuery.of(context).viewInsets.bottom + 16,
        ),
        child: StatefulBuilder(
          builder: (context, setState) {
            return Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Row(
                  children: [
                    IconButton(
                      icon: Icon(Icons.close),
                      onPressed: () => Navigator.pop(context),
                    ),
                    Spacer(),
                    Text(
                      "New Post",
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 16,
                      ),
                    ),
                    Spacer(),
                    TextButton(
                      onPressed: () async {
                        Navigator.pop(context);
                        await _uploadPost(
                          _selectedMedia!,
                          _caption,
                          setUploading,
                          context,
                        );
                      },
                      child: Text(
                        "Post",
                        style: TextStyle(fontWeight: FontWeight.bold),
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 12),
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    ClipRRect(
                      borderRadius: BorderRadius.circular(12),
                      child: Image.file(
                        _selectedMedia!,
                        width: 80,
                        height: 80,
                        fit: BoxFit.cover,
                      ),
                    ),
                    SizedBox(width: 12),
                    Expanded(
                      child: TextField(
                        maxLines: null,
                        decoration: InputDecoration(
                          hintText: "Write a caption...",
                          border: InputBorder.none,
                        ),
                        onChanged: (val) => _caption = val,
                      ),
                    ),
                  ],
                ),
              ],
            );
          },
        ),
      );
    },
  );
}

Future<void> _uploadPost(
  File media,
  String caption,
  Function(bool) setUploading,
  BuildContext context,
) async {
  setUploading(true);

  try {
    final userId = FirebaseAuth.instance.currentUser?.uid ?? "anonymous";
    final postId = FirebaseFirestore.instance.collection('posts').doc().id;
    final storageRef = FirebaseStorage.instance.ref().child(
      'posts/$userId/$postId',
    );

    await storageRef.putFile(media);
    final mediaUrl = await storageRef.getDownloadURL();

    await FirebaseFirestore.instance.collection('posts').doc(postId).set({
      'caption': caption,
      'mediaUrl': mediaUrl,
      'userId': userId,
      'timestamp': FieldValue.serverTimestamp(),
      'likes': {},
    });
  } catch (e) {
    print('Upload failed: $e');
    ScaffoldMessenger.of(
      context,
    ).showSnackBar(SnackBar(content: Text("Upload failed")));
  } finally {
    setUploading(false);
  }
}
