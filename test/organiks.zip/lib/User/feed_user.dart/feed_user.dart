// import 'dart:io';
import 'package:flutter/material.dart';
// import 'package:image_picker/image_picker.dart';
// import 'editing.dart';

class FeedPageUser extends StatefulWidget {
  @override
  _FeedPageState createState() => _FeedPageState();
}

class _FeedPageState extends State<FeedPageUser> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF2A2B60),
      appBar: AppBar(
        backgroundColor: const Color(0xFF2A2B60),
        title: const Text('Organiks Girls', style: TextStyle(color: Colors.white)),
        actions: [
          IconButton(
            icon: const Icon(Icons.chat, color: Color(0xFFB06B9F)),
            onPressed: () {},
          ),
        ],
      ),
      // Removed floatingActionButton
      body: Center(
        child: Text('No posts yet', style: TextStyle(color: Colors.white70)),
      ),
    );
  }
}
